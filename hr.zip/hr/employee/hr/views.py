from django.shortcuts import render

# Create your views here.
# hr/views.py

from django.http import HttpResponse

def index(request):
    return HttpResponse("Hello, this is the HR app index page.")
