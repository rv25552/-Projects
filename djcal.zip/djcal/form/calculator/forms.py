from django import forms

class CalculatorForm(forms.Form):
    num1 = forms.FloatField(label='Number 1', required=True)
    num2 = forms.FloatField(label='Number 2', required=True)
    operation = forms.ChoiceField(label='Operation', choices=[
        ('add', 'Addition'),
        ('subtract', 'Subtraction'),
        ('multiply', 'Multiplication'),
        ('divide', 'Division')
    ])
